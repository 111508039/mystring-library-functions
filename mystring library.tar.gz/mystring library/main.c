#include<stdio.h>
#include"mystring.h"
#include<string.h>
int main() {
	char text[100],in[100];
	//int m, n;
	char c;
	//scanf("%c",&t);        
	gets(text);
	//scanf("%c",&c); 
	//int m;
	gets(in);
	//scanf("%s",text);
	//scanf("%s",in);
	//s=stpcpy(text ,in);
	//char *token=strtok(text,in);
	//char *m= strtok(text,in);
	char *n= mystrtok(text,in);
	//char *m =myrindex(text,c);
	//n =mystrncmp(text,in,0);
	//scanf("%c",&c); 
	//char *s=mymemcpy(text,in,m);
	//char *m=(char *)mymemset(text,c,4);
	//printf("%s\n%s",m,n);
	//n=strspn(text,in);
}       

